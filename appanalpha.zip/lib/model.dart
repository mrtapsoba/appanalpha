class Model {
  static String? num;
  static String? lang;
}
